/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testfuzzylogic;

import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.plot.JFuzzyChart;
import net.sourceforge.jFuzzyLogic.rule.Variable;

/**
 *
 * @author juraj.sojcak
 */
public class TestFuzzyLogic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String fileName = "c:\\Users\\juraj.sojcak\\Documents\\NetBeansProjects\\sumo_jade\\src\\fcl\\crossroad.fcl";
        FIS fis = FIS.load(fileName, true);

        // Error while loading?
        if (fis == null) {
            System.err.println("Can't load file: '" + fileName + "'");
            return;
        }

        // Show 
        JFuzzyChart.get().chart(fis);
        // Set inputs
        for (int i = 0; i <= 15; i++) {
            fis.setVariable("main_road", 14);
            fis.setVariable("second_road", i);
            fis.evaluate();

            Variable time = fis.getVariable("time");
            System.out.println("i: " +  i + " output: " + time.defuzzify());
        }
        fis.getVariable("time").getUniverseMax();
//        // Evaluate
//
//        // Show output variable's chart
//        Variable tip = fis.getVariable("tip");
//        System.out.println(tip.defuzzify());
        fis.setVariable("main_road", fis.getVariable("time").getUniverseMax());
        fis.setVariable("second_road", 0);
        fis.evaluate();

        Variable time = fis.getVariable("time");
        JFuzzyChart.get().chart(time, time.getDefuzzifier(), true);
//        
        //System.exit(42);
        // Print ruleSet
        //System.out.println(fis);
    }

}
